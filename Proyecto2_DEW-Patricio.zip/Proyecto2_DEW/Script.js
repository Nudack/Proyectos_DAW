// Creación de los aviones con su información
class Avion {
    constructor(nombre, filas, columnas, precios) {
        this.nombre = nombre;
        this.filas = filas;
        this.columnas = columnas;
        this.precios = precios;
        this.asientos = generarAsientosAleatorios(filas, columnas);
    }

    reservarAsiento(fila, columna) {
        if (this.asientos[fila][columna]) {
            this.asientos[fila][columna] = false; // Marcar como ocupado
        }
    }

    liberarAsiento(fila, columna) {
        if (!this.asientos[fila][columna]){
            this.asientos[fila][columna] = true;
        }
    }
}

// Definir los aviones
const avionBlanco = new Avion('Avión Blanco', 10, 4, { business: 300, economica: 200, lowCost: 70 });
const avionAzul = new Avion('Avión Azul', 18, 6, { business: 250, economica: 175, lowCost: 60 });
const avionAmarillo = new Avion('Avión Amarillo', 24, 6, { business: 200, economica: 125, lowCost: 50 });

// Función para generar asientos aleatoriamente ocupados o libres
function generarAsientosAleatorios(filas, columnas, probabilidadOcupado = 0.45) {
    return Array.from({ length: filas }, () =>
        Array.from({ length: columnas }, () => Math.random() < probabilidadOcupado ? false : true)
    );
}

// Función para mostrar los asientos y permitir la selección
function generarTablaAsientos(avion, categoria) {
    let tablaHtml = `<tr><th colspan="${avion.columnas}">${categoria.toUpperCase()} - Precio: ${avion.precios[categoria]}€</th></tr>`;
    for (let i = 0; i < avion.filas; i++) {
        tablaHtml += "<tr>";
        for (let j = 0; j < avion.columnas; j++) {
            const disponible = avion.asientos[i][j];
            const color = disponible ? "green" : "red";
            const eventoClic = disponible ? `onclick="reservar(${i},${j})"` : ''; // Solo si está libre
            tablaHtml += `<td style="background-color:${color}; cursor: pointer;" ${eventoClic}>${disponible ? 'Libre' : 'Ocupado'}</td>`;
        }
        tablaHtml += "</tr>";
    }
    return tablaHtml;
}

// Función para reservar un asiento
function reservar(fila, columna) {
    const categoria = document.getElementById('categoria').value;
    let avion;

    if (window.location.href.includes('avionBlanco')) {
        avion = avionBlanco;
    } else if (window.location.href.includes('avionAzul')) {
        avion = avionAzul;
    } else if (window.location.href.includes('avionAmarillo')) {
        avion = avionAmarillo;
    }

    if (avion.asientos[fila][columna]) {
        // Reservar asiento
        if(confirm(`¿Quieres reservar el asiento en fila ${fila + 1}, columna ${columna + 1} en categoría ${categoria}.?`)){
            avion.reservarAsiento(fila, columna);
            mostrarFormularioFinal(categoria, fila, columna);
        }
        else{
            avion.liberarAsiento(fila, columna)
            mostrarFormularioFinal(categoria, fila, columna);
        }

    } else {
        alert('Este asiento ya está ocupado.');
    }

    // Actualizar la tabla de asientos después de reservar
    mostrarAsientos();
}

// Función para mostrar los asientos según el avión y la categoría seleccionada
function mostrarAsientos() {
    const categoria = document.getElementById('categoria').value;
    let avion;

    if (window.location.href.includes('avionBlanco')) {
        avion = avionBlanco;
    } else if (window.location.href.includes('avionAzul')) {
        avion = avionAzul;
    } else if (window.location.href.includes('avionAmarillo')) {
        avion = avionAmarillo;
    }

    const tabla = document.createElement('table');
    tabla.innerHTML = generarTablaAsientos(avion, categoria);
    document.getElementById('tablaAsientos').innerHTML = "";
    document.getElementById('tablaAsientos').appendChild(tabla);
}

// Función para mostrar el formulario de complementos basado en la categoría
function mostrarFormularioFinal(categoria, fila, columna) {
    let residente = confirm("¿Eres residente? (Obtendrás un 75% de descuento)");
    let total = 0;
    let precioAsiento = 0;

    // Complementos según la categoría
    if (categoria == "lowCost") {
        alert(`Estás en la categoría Low Cost. Se aplicarán los siguientes cargos obligatorios.`);
        precioAsiento = 5; // Low-cost paga por elección de asiento
        total += precioAsiento;

        let maleta10kg = confirm("¿Quieres añadir una maleta de 10Kg? (+30€)");
        if (maleta10kg) total += 30;

        let maleta25kg = confirm("¿Quieres añadir una maleta de 25Kg? (+45€)");
        if (maleta25kg) total += 45;

        let embarque = confirm("¿Quieres añadir embarque prioritario? (+10€)");
        if (embarque) total += 10;

        let menu = confirm("¿Quieres añadir un menú a bordo? (+20€)");
        if (menu) total += 20;

    } else if (categoria == "economica") {
        alert(`Estás en la categoría Económica.`);
        let asiento = confirm(`¿Quieres elegir el asiento Fila ${fila + 1}, Columna ${columna + 1}? (+5€)`);
        if (asiento) total += 5;

        let maleta25kg = confirm("¿Quieres añadir una maleta de 25Kg? (+45€)");
        if (maleta25kg) total += 45;

        let menu = confirm("¿Quieres añadir un menú a bordo? (+20€)");
        if (menu) total += 20;

    } else if (categoria == "business") {
        alert(`Estás en la categoría Business. Puedes elegir el asiento sin coste adicional.`);
        let asiento = confirm(`¿Quieres elegir el asiento Fila ${fila + 1}, Columna ${columna + 1}?`);
        if (asiento) total += 0; // Sin cargo por elegir asiento en business

        // Opciones adicionales que no tienen costo en Business
        let menu = confirm("¿Quieres añadir un menú a bordo? (+20€)");
        if (menu) total += 20;
    }

    // Agregar el precio base del billete según la categoría
    let avion;
    if (window.location.href.includes('avionBlanco')) {
        avion = avionBlanco;
    } else if (window.location.href.includes('avionAzul')) {
        avion = avionAzul;
    } else if (window.location.href.includes('avionAmarillo')) {
        avion = avionAmarillo;
    }

    total += avion.precios[categoria];

    // Aplicar descuento por residente
    if (residente) {
        total *= 0.25; // Aplicar 75% de descuento
    }

    // Mostrar el precio final
    alert(`El precio total de tu billete es: ${total.toFixed(2)}€`);

    // Preguntar si quiere cambiar su elección
    let cambiar = confirm("¿Quieres cambiar tu elección?");
    if (cambiar) {
        mostrarAsientos(); // Reiniciar el proceso si desea cambiar la elección
    }
}